@extends('layouts.scaffold')


@section('title')
@parent
:: Stories
@stop

@section('css')
  <link type="text/css" charset="utf-8" rel="stylesheet" media="screen" href="{{ asset('css/home.css')}}" />
  <!-- leaflet CSS file -->
  <link type="text/css" rel="stylesheet" href="{{ asset('leaflet/leaflet.css')}}" />
  <link type="text/css" rel="stylesheet" href="{{ asset('leaflet_label/leaflet.label.css')}}" />
@stop

@section('main')
<!-- replace the content below to suit your page content -->

<div class="bladenav brick">
  <div class="">
    <a href="/devs"><div class="_strip">DEVELOPERS</div><!-- <div class="_tail"></div> --></a>
  </div>
  <div class="">
    <a href="/orgs"><div class="_strip">ORGANISATIONS</div><!-- <div class="_tail"></div> --></a>
  </div>
   <div class="">
    <a href="/projects"><div class="_strip">PROJECTS</div><!-- <div class="_tail"></div> --></a>
  </div>
   <div class="">
    <a href="/eventts"><div class="_strip">EVENTS</div><!-- <div class="_tail"></div> --></a>
  </div>
   <div class="">
    <a href="/stories"><div class="_strip">STORIES</div><!-- <div class="_tail"></div> --></a>
  </div>
</div>


<div id="map"></div>

<div class="_addbtn _charm _step1">+Add</div>

<div class="_alert _bg"></div>
<div class="_alert _pink _hide"></div>
<div class="_alert _data">Click on the map to add an organisation, project, event or story...</div>
<div class="_content">

<h1>All Stories</h1>

<!-- <p>{{ link_to_route('stories.create', 'Add new story') }}</p> -->

@if ($stories->count())
	<table class="table table-striped table-bordered">
		<thead>
			<tr>
				<th>Name</th>
				<th>Creator</th>
				<th>Body</th>
				<th>Location</th>
				<th>Views</th>
				<th>Votes</th>
			</tr>
		</thead>

		<tbody>
			@foreach ($stories as $story)
				<tr>
					<td><a href="{{ URL::to('stories/'.$story->id) }}">{{{ $story->name }}}</a></td>
					<td>{{{ $story->creator }}}</td>
					<td>{{{ $story->body }}}</td>
					<td>{{{ $story->location }}}</td>
					<td>{{{ $story->views }}}</td>
					<td>{{{ $story->votes }}}</td>
				</tr>
			@endforeach
		</tbody>
	</table>
@else
	There are no stories
@endif
</div>
@stop
